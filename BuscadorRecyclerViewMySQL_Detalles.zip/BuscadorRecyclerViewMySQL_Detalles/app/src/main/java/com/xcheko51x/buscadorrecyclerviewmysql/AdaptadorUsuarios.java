package com.xcheko51x.buscadorrecyclerviewmysql;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class AdaptadorUsuarios extends RecyclerView.Adapter<AdaptadorUsuarios.UsuarioViewHolder> {

    Context context;
    List<Usuario> listaUsuarios;

    public AdaptadorUsuarios(Context context, List<Usuario> listaUsuarios) {
        this.context = context;
        this.listaUsuarios = listaUsuarios;
    }

    @NonNull
    @Override
    public UsuarioViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_rv_usuario, viewGroup, false);
        return new UsuarioViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull UsuarioViewHolder usuarioViewHolder, final int i) {
        usuarioViewHolder.tvIdUsuario.setText(listaUsuarios.get(i).getIdUsuario());
        usuarioViewHolder.tvNombre.setText(listaUsuarios.get(i).getNombre());
        usuarioViewHolder.tvTelefono.setText(listaUsuarios.get(i).getTelefono());
        usuarioViewHolder.tvEmail.setText(listaUsuarios.get(i).getEmail());

        usuarioViewHolder.cvTarjeta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DetallesUsuario.class);
                intent.putExtra("usuario", listaUsuarios.get(i));
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaUsuarios.size();
    }

    public class UsuarioViewHolder extends RecyclerView.ViewHolder {

        CardView cvTarjeta;
        TextView tvIdUsuario, tvNombre, tvTelefono, tvEmail;

        public UsuarioViewHolder(@NonNull View itemView) {
            super(itemView);

            cvTarjeta = itemView.findViewById(R.id.cvTarjeta);
            tvIdUsuario = itemView.findViewById(R.id.tvIdUsuario);
            tvNombre = itemView.findViewById(R.id.tvNombre);
            tvTelefono = itemView.findViewById(R.id.tvTelefono);
            tvEmail = itemView.findViewById(R.id.tvEmail);
        }
    }

    public void filtrar(ArrayList<Usuario> filtroUsuarios) {
        this.listaUsuarios = filtroUsuarios;
        notifyDataSetChanged();
    }
}
