package com.xcheko51x.buscadorrecyclerviewmysql;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class DetallesUsuario extends AppCompatActivity {

    TextView tvDetalles;

    Usuario usuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalles_usuario);

        usuario = (Usuario) getIntent().getSerializableExtra("usuario");

        tvDetalles = findViewById(R.id.tvDetalles);

        tvDetalles.setText("ID: "+usuario.getIdUsuario()+"\n\nNombre: "+usuario.getNombre());
        
    }
}
